"""CONTROLADOR: las 5 operaciones (crear, listar, buscar, actualizar, eliminar)
para las 3 entidades, más las operaciones académicas (notas, promedios, conjuntos)."""
from models import Estudiante, Materia, Inscripcion
from shared.json_manager import cargar, guardar


class Controlador:
    """Las 5 operaciones genéricas; cada entidad define su modelo, archivo y validaciones."""
    modelo = None
    archivo = None
    campo_clave = None  # campo único alterno al id (carnet, codigo)

    # ---------- persistencia ----------
    def _todos(self):
        return [self.modelo.from_dict(d) for d in cargar(self.archivo)]

    def _guardar(self, items):
        guardar(self.archivo, [i.to_dict() for i in items])

    def validar(self, datos, items, id_actual=None):
        """Gancho: las subclases lanzan ValueError si los datos no son válidos."""

    # ---------- las 5 operaciones ----------
    def crear(self, **datos):
        items = self._todos()
        self.validar(datos, items)
        nuevo_id = max((i.id for i in items), default=0) + 1
        obj = self.modelo(id=nuevo_id, **datos)
        items.append(obj)
        self._guardar(items)
        return obj

    def listar(self):
        return self._todos()

    def buscar(self, valor):
        """Busca por id o por el campo clave (carnet / código)."""
        valor = str(valor).strip()
        for i in self._todos():
            if str(i.id) == valor:
                return i
            if self.campo_clave and str(getattr(i, self.campo_clave)).lower() == valor.lower():
                return i
        return None

    def actualizar(self, valor, **cambios):
        items = self._todos()
        obj = next((i for i in items if i is not None and self._coincide(i, valor)), None)
        if obj is None:
            return None
        self.validar(cambios, items, id_actual=obj.id)
        for campo, nuevo in cambios.items():
            if campo not in ("id", "notas") and hasattr(obj, campo):
                setattr(obj, campo, nuevo)
        self._guardar(items)
        return obj

    def eliminar(self, valor):
        items = self._todos()
        obj = next((i for i in items if self._coincide(i, valor)), None)
        if obj is None:
            return None
        items.remove(obj)
        self._guardar(items)
        return obj

    def _coincide(self, item, valor):
        valor = str(valor).strip()
        if str(item.id) == valor:
            return True
        return bool(self.campo_clave) and str(getattr(item, self.campo_clave)).lower() == valor.lower()


# ============================ ESTUDIANTES ============================
class ControladorEstudiantes(Controlador):
    modelo = Estudiante
    archivo = "estudiantes.json"
    campo_clave = "carnet"

    def validar(self, datos, items, id_actual=None):
        carnets = {e.carnet.lower() for e in items if e.id != id_actual}  # set: carnet único
        if "carnet" in datos and datos["carnet"].lower() in carnets:
            raise ValueError(f"El carnet {datos['carnet']} ya está registrado.")

    def eliminar(self, valor):
        est = super().eliminar(valor)
        if est:  # al borrar un estudiante se borran sus inscripciones
            ControladorInscripciones().eliminar_donde(lambda i: i.carnet == est.carnet)
        return est

    # --- operaciones académicas ---
    def agregar_nota(self, carnet, codigo_materia, nota):
        items = self._todos()
        est = next((e for e in items if e.carnet.lower() == carnet.lower()), None)
        if est is None:
            raise ValueError("No existe un estudiante con ese carnet.")
        if codigo_materia not in ControladorInscripciones().materias_de(est.carnet):
            raise ValueError("El estudiante no está inscrito en esa materia.")
        est.agregar_nota(codigo_materia, nota)  # valida 0 a 20
        self._guardar(items)
        return est

    def promedio(self, carnet, codigo_materia=None):
        est = self.buscar(carnet)
        if est is None:
            raise ValueError("No existe un estudiante con ese carnet.")
        return est, est.promedio(codigo_materia)


# ============================== MATERIAS ==============================
class ControladorMaterias(Controlador):
    modelo = Materia
    archivo = "materias.json"
    campo_clave = "codigo"

    def validar(self, datos, items, id_actual=None):
        codigos = {m.codigo.lower() for m in items if m.id != id_actual}
        if "codigo" in datos and datos["codigo"].lower() in codigos:
            raise ValueError(f"El código {datos['codigo']} ya existe.")
        if "creditos" in datos and datos["creditos"] <= 0:
            raise ValueError("Los créditos deben ser mayores a 0.")

    def eliminar(self, valor):
        mat = super().eliminar(valor)
        if mat:
            ControladorInscripciones().eliminar_donde(lambda i: i.codigo_materia == mat.codigo)
        return mat

    def materias_ofertadas(self):
        """Conjunto de códigos de las materias disponibles."""
        return {m.codigo for m in self._todos()}


# ============================ INSCRIPCIONES ============================
class ControladorInscripciones(Controlador):
    modelo = Inscripcion
    archivo = "inscripciones.json"

    def validar(self, datos, items, id_actual=None):
        if "carnet" in datos or "codigo_materia" in datos:
            carnet = datos.get("carnet")
            codigo = datos.get("codigo_materia")
            if carnet is not None and ControladorEstudiantes().buscar(carnet) is None:
                raise ValueError("El estudiante no existe.")
            if codigo is not None and codigo not in ControladorMaterias().materias_ofertadas():
                raise ValueError("La materia no está ofertada.")
            actual = next((i for i in items if i.id == id_actual), None)
            c = carnet if carnet is not None else (actual.carnet if actual else None)
            m = codigo if codigo is not None else (actual.codigo_materia if actual else None)
            if any(i.carnet == c and i.codigo_materia == m and i.id != id_actual for i in items):
                raise ValueError("El estudiante ya está inscrito en esa materia.")

    def eliminar_donde(self, condicion):
        items = [i for i in self._todos() if not condicion(i)]
        self._guardar(items)

    def materias_de(self, carnet):
        return {i.codigo_materia for i in self._todos() if i.carnet.lower() == carnet.lower()}

    def estudiantes_de(self, codigo_materia):
        return {i.carnet for i in self._todos() if i.codigo_materia.lower() == codigo_materia.lower()}

    def estudiantes_en_comun(self, materia_a, materia_b):
        """Intersección de los conjuntos de carnets inscritos en ambas materias."""
        return self.estudiantes_de(materia_a) & self.estudiantes_de(materia_b)
