"""VISTA: menús, input() y print(). Toda la lógica vive en views.py (controlador)."""
from views import ControladorEstudiantes, ControladorMaterias, ControladorInscripciones
from shared.herramientas import (limpiar_pantalla, pausar, pedir_texto, pedir_entero,
                                 pedir_decimal, confirmar, imprimir_lista)

estudiantes = ControladorEstudiantes()
materias = ControladorMaterias()
inscripciones = ControladorInscripciones()


def mostrar_menu(titulo, opciones):
    limpiar_pantalla()
    print(f"\n=== {titulo} ===")
    for clave, texto in opciones:
        print(f"  {clave}. {texto}")
    return input("\nOpción: ").strip()


def ejecutar(accion):
    """Ejecuta una acción mostrando los errores de validación sin cerrar el programa."""
    try:
        accion()
    except ValueError as error:
        print(f"\n  ✖ {error}")
    pausar()


# ------------------------------ ESTUDIANTES ------------------------------
def crear_estudiante():
    est = estudiantes.crear(
        carnet=pedir_texto("Carnet: "), nombre=pedir_texto("Nombre: "),
        apellido=pedir_texto("Apellido: "), correo=pedir_texto("Correo: "))
    print(f"\n  ✔ Creado: {est}")


def listar_estudiantes():
    imprimir_lista(estudiantes.listar())


def buscar_estudiante():
    est = estudiantes.buscar(pedir_texto("Id o carnet: "))
    print(f"\n  {est}" if est else "\n  No encontrado.")


def actualizar_estudiante():
    valor = pedir_texto("Id o carnet a actualizar: ")
    if not estudiantes.buscar(valor):
        return print("\n  No encontrado.")
    print("(deje vacío para mantener el valor actual)")
    cambios = {}
    for campo in ("carnet", "nombre", "apellido", "correo"):
        nuevo = pedir_texto(f"Nuevo {campo}: ", obligatorio=False)
        if nuevo:
            cambios[campo] = nuevo
    est = estudiantes.actualizar(valor, **cambios)
    print(f"\n  ✔ Actualizado: {est}")


def eliminar_estudiante():
    valor = pedir_texto("Id o carnet a eliminar: ")
    if confirmar("¿Seguro? Se borrarán también sus inscripciones"):
        est = estudiantes.eliminar(valor)
        print(f"\n  ✔ Eliminado: {est}" if est else "\n  No encontrado.")


# ------------------------------- MATERIAS -------------------------------
def crear_materia():
    mat = materias.crear(codigo=pedir_texto("Código: "), nombre=pedir_texto("Nombre: "),
                         creditos=pedir_entero("Créditos: ", 1, 20))
    print(f"\n  ✔ Creada: {mat}")


def listar_materias():
    imprimir_lista(materias.listar())


def buscar_materia():
    mat = materias.buscar(pedir_texto("Id o código: "))
    print(f"\n  {mat}" if mat else "\n  No encontrada.")


def actualizar_materia():
    valor = pedir_texto("Id o código a actualizar: ")
    if not materias.buscar(valor):
        return print("\n  No encontrada.")
    print("(deje vacío para mantener el valor actual)")
    cambios = {}
    for campo in ("codigo", "nombre"):
        nuevo = pedir_texto(f"Nuevo {campo}: ", obligatorio=False)
        if nuevo:
            cambios[campo] = nuevo
    cred = pedir_texto("Nuevos créditos: ", obligatorio=False)
    if cred:
        if not cred.isdigit():
            raise ValueError("Los créditos deben ser un número entero.")
        cambios["creditos"] = int(cred)
    print(f"\n  ✔ Actualizada: {materias.actualizar(valor, **cambios)}")


def eliminar_materia():
    valor = pedir_texto("Id o código a eliminar: ")
    if confirmar("¿Seguro? Se borrarán también sus inscripciones"):
        mat = materias.eliminar(valor)
        print(f"\n  ✔ Eliminada: {mat}" if mat else "\n  No encontrada.")


# ----------------------------- INSCRIPCIONES -----------------------------
def crear_inscripcion():
    ins = inscripciones.crear(carnet=pedir_texto("Carnet del estudiante: "),
                              codigo_materia=pedir_texto("Código de la materia: "))
    print(f"\n  ✔ Creada: {ins}")


def listar_inscripciones():
    imprimir_lista(inscripciones.listar())


def buscar_inscripcion():
    ins = inscripciones.buscar(pedir_texto("Id de la inscripción: "))
    print(f"\n  {ins}" if ins else "\n  No encontrada.")


def actualizar_inscripcion():
    valor = pedir_texto("Id de la inscripción a actualizar: ")
    if not inscripciones.buscar(valor):
        return print("\n  No encontrada.")
    print("(deje vacío para mantener el valor actual)")
    cambios = {}
    for campo, etiqueta in (("carnet", "carnet"), ("codigo_materia", "código de materia")):
        nuevo = pedir_texto(f"Nuevo {etiqueta}: ", obligatorio=False)
        if nuevo:
            cambios[campo] = nuevo
    print(f"\n  ✔ Actualizada: {inscripciones.actualizar(valor, **cambios)}")


def eliminar_inscripcion():
    valor = pedir_texto("Id de la inscripción a eliminar: ")
    if confirmar("¿Seguro?"):
        ins = inscripciones.eliminar(valor)
        print(f"\n  ✔ Eliminada: {ins}" if ins else "\n  No encontrada.")


# --------------------------- NOTAS Y REPORTES ---------------------------
def agregar_nota():
    carnet = pedir_texto("Carnet: ")
    codigo = pedir_texto("Código de la materia: ")
    nota = pedir_decimal("Nota (0 a 20): ")
    estudiantes.agregar_nota(carnet, codigo, nota)
    print("\n  ✔ Nota registrada.")


def ver_promedio():
    carnet = pedir_texto("Carnet: ")
    codigo = pedir_texto("Código de materia (vacío = promedio general): ", obligatorio=False)
    est, prom = estudiantes.promedio(carnet, codigo or None)
    alcance = f"en {codigo}" if codigo else "general"
    print(f"\n  {est.nombre_completo}: promedio {alcance} = {prom if prom is not None else 'sin notas'}")


def materias_ofertadas():
    ofertadas = sorted(materias.materias_ofertadas())
    print("\n  Materias ofertadas:", ", ".join(ofertadas) if ofertadas else "ninguna")


def materias_en_comun():
    a = pedir_texto("Código de la materia A: ")
    b = pedir_texto("Código de la materia B: ")
    comunes = sorted(inscripciones.estudiantes_en_comun(a, b))
    print(f"\n  Estudiantes en común entre {a} y {b}:",
          ", ".join(comunes) if comunes else "ninguno")


# ------------------------------- SUBMENÚS -------------------------------
def submenu_crud(titulo, acciones):
    opciones = [("1", "Crear"), ("2", "Listar"), ("3", "Buscar"),
                ("4", "Actualizar"), ("5", "Eliminar"), ("0", "Volver")]
    while True:
        op = mostrar_menu(titulo, opciones)
        if op == "0":
            return
        if op in acciones:
            ejecutar(acciones[op])
        else:
            print("  Opción inválida.")
            pausar()


def submenu_notas():
    opciones = [("1", "Agregar nota"), ("2", "Ver promedio"),
                ("3", "Materias ofertadas"), ("4", "Materias en común"), ("0", "Volver")]
    acciones = {"1": agregar_nota, "2": ver_promedio,
                "3": materias_ofertadas, "4": materias_en_comun}
    while True:
        op = mostrar_menu("NOTAS Y REPORTES", opciones)
        if op == "0":
            return
        if op in acciones:
            ejecutar(acciones[op])
        else:
            print("  Opción inválida.")
            pausar()


def main():
    opciones = [("1", "Estudiantes"), ("2", "Materias"), ("3", "Inscripciones"),
                ("4", "Notas y reportes"), ("0", "Salir")]
    while True:
        op = mostrar_menu("SISTEMA ACADÉMICO", opciones)
        if op == "1":
            submenu_crud("ESTUDIANTES", {"1": crear_estudiante, "2": listar_estudiantes,
                                         "3": buscar_estudiante, "4": actualizar_estudiante,
                                         "5": eliminar_estudiante})
        elif op == "2":
            submenu_crud("MATERIAS", {"1": crear_materia, "2": listar_materias,
                                      "3": buscar_materia, "4": actualizar_materia,
                                      "5": eliminar_materia})
        elif op == "3":
            submenu_crud("INSCRIPCIONES", {"1": crear_inscripcion, "2": listar_inscripciones,
                                           "3": buscar_inscripcion, "4": actualizar_inscripcion,
                                           "5": eliminar_inscripcion})
        elif op == "4":
            submenu_notas()
        elif op == "0":
            print("\n¡Hasta luego!")
            break
        else:
            print("  Opción inválida.")
            pausar()


if __name__ == "__main__":
    main()
