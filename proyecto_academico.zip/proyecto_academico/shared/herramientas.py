"""Funciones reutilizables para la vista (entrada de datos y pantalla)."""
import os


def limpiar_pantalla():
    os.system("cls" if os.name == "nt" else "clear")


def pausar():
    input("\nPresione ENTER para continuar...")


def pedir_texto(mensaje, obligatorio=True):
    while True:
        valor = input(mensaje).strip()
        if valor or not obligatorio:
            return valor
        print("  ⚠ Este campo no puede estar vacío.")


def pedir_entero(mensaje, minimo=None, maximo=None):
    while True:
        try:
            valor = int(input(mensaje).strip())
        except ValueError:
            print("  ⚠ Ingrese un número entero.")
            continue
        if (minimo is not None and valor < minimo) or (maximo is not None and valor > maximo):
            print(f"  ⚠ El valor debe estar entre {minimo} y {maximo}.")
            continue
        return valor


def pedir_decimal(mensaje):
    while True:
        try:
            return float(input(mensaje).strip().replace(",", "."))
        except ValueError:
            print("  ⚠ Ingrese un número válido.")


def confirmar(mensaje):
    return input(f"{mensaje} (s/n): ").strip().lower() == "s"


def imprimir_lista(items, vacio="No hay registros."):
    if not items:
        print(f"  {vacio}")
        return
    for item in items:
        print(" ", item)
