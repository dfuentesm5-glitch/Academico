"""Lectura/escritura de archivos JSON dentro de data/ (se crean automáticamente)."""
import json
import os

DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")


def _ruta(nombre):
    os.makedirs(DATA_DIR, exist_ok=True)
    return os.path.join(DATA_DIR, nombre)


def guardar(nombre, datos):
    with open(_ruta(nombre), "w", encoding="utf-8") as f:
        json.dump(datos, f, indent=4, ensure_ascii=False)


def cargar(nombre):
    """Devuelve la lista guardada; si el archivo no existe o está dañado, lo crea vacío."""
    ruta = _ruta(nombre)
    if not os.path.exists(ruta):
        guardar(nombre, [])
        return []
    try:
        with open(ruta, "r", encoding="utf-8") as f:
            return json.load(f)
    except json.JSONDecodeError:
        guardar(nombre, [])
        return []
