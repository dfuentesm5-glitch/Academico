"""MODELO: ModeloBase -> Persona -> Estudiante · Materia · Inscripcion"""
from datetime import datetime


class ModeloBase:
    """Base de todas las entidades: id + (de)serialización a dict."""

    def __init__(self, id=None):
        self.id = id

    def to_dict(self):
        return dict(self.__dict__)

    @classmethod
    def from_dict(cls, datos):
        obj = cls.__new__(cls)
        obj.__dict__.update(datos)
        return obj


class Persona(ModeloBase):
    def __init__(self, id=None, nombre="", apellido="", correo=""):
        super().__init__(id)
        self.nombre = nombre
        self.apellido = apellido
        self.correo = correo

    @property
    def nombre_completo(self):
        return f"{self.nombre} {self.apellido}"


class Estudiante(Persona):
    NOTA_MIN = 0
    NOTA_MAX = 20

    def __init__(self, id=None, nombre="", apellido="", correo="", carnet=""):
        super().__init__(id, nombre, apellido, correo)
        self.carnet = carnet
        self.notas = {}  # {codigo_materia: [nota, nota, ...]}

    def agregar_nota(self, codigo_materia, nota):
        if not (self.NOTA_MIN <= nota <= self.NOTA_MAX):
            raise ValueError(f"La nota debe estar entre {self.NOTA_MIN} y {self.NOTA_MAX}.")
        self.notas.setdefault(codigo_materia, []).append(nota)

    def promedio(self, codigo_materia=None):
        """Promedio de una materia, o general si no se indica materia."""
        if codigo_materia is not None:
            lista = self.notas.get(codigo_materia, [])
        else:
            lista = [n for notas in self.notas.values() for n in notas]
        return round(sum(lista) / len(lista), 2) if lista else None

    def __str__(self):
        return f"[{self.id}] {self.carnet} | {self.nombre_completo} | {self.correo}"


class Materia(ModeloBase):
    def __init__(self, id=None, codigo="", nombre="", creditos=0):
        super().__init__(id)
        self.codigo = codigo
        self.nombre = nombre
        self.creditos = creditos

    def __str__(self):
        return f"[{self.id}] {self.codigo} | {self.nombre} | {self.creditos} créditos"


class Inscripcion(ModeloBase):
    """Equivale a la 'Venta' del proyecto base: relaciona estudiante y materia."""

    def __init__(self, id=None, carnet="", codigo_materia="", fecha=None):
        super().__init__(id)
        self.carnet = carnet
        self.codigo_materia = codigo_materia
        self.fecha = fecha or datetime.now().strftime("%Y-%m-%d %H:%M")

    def __str__(self):
        return f"[{self.id}] {self.carnet} -> {self.codigo_materia} ({self.fecha})"
